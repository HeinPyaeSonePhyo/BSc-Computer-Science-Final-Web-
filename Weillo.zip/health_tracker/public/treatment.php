<?php
session_start();
require_once __DIR__ . '/../config/Database.php';
require_once __DIR__ . '/../controllers/AppointmentController.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

date_default_timezone_set('Europe/London');

$db = (new Database())->getConnection();
$appointmentController = new AppointmentController($db);
$userId = (int)$_SESSION['user_id'];

$appointments = $appointmentController->listAll($userId);

$providers = [
    ['name' => 'St Thomas Hospital', 'type' => 'Hospital'],
    ['name' => 'Guys Hospital', 'type' => 'Hospital'],
    ['name' => 'City Health Clinic', 'type' => 'Clinic'],
    ['name' => 'Community GP Practice', 'type' => 'GP'],
    ['name' => 'Boots Pharmacy Clinic', 'type' => 'Pharmacy'],
    ['name' => 'Central Care Centre', 'type' => 'Clinic'],
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Get Treatment</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
  <link rel="stylesheet" href="style.css?v=design-refresh-1">
</head>
<body>
<div class="app-shell d-flex">
  <?php include __DIR__ . '/sidebar.php'; ?>

  <div class="flex-grow-1">
    <div class="topbar container py-3 d-flex align-items-center justify-content-between">
      <button class="btn btn-outline-secondary d-inline-flex align-items-center gap-2 d-md-none" id="sidebarToggle">
        <i class="bi bi-list"></i> Menu
      </button>
      <div class="ms-auto">
        <p class="fw-semibold text-purple fs-5 mb-0">
          <i class="bi bi-hospital me-2"></i>Get Treatment
        </p>
      </div>
    </div>

    <main id="content">
      <div class="container pb-5">

        <?php if (!empty($_SESSION['appointment_success'])): ?>
          <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?= htmlspecialchars($_SESSION['appointment_success']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
          </div>
          <?php unset($_SESSION['appointment_success']); ?>
        <?php endif; ?>

        <?php if (!empty($_SESSION['appointment_error'])): ?>
          <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?= htmlspecialchars($_SESSION['appointment_error']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
          </div>
          <?php unset($_SESSION['appointment_error']); ?>
        <?php endif; ?>

        <div class="card p-4 shadow-sm border-0 mb-4">
          <h4 class="fw-bold text-purple mb-3">Book an Appointment</h4>

          <form id="apptForm" class="row g-3" method="POST" action="save_appointment.php">
            <div class="col-md-6">
              <label class="form-label">Choose Provider</label>
              <select id="providerSelect" name="provider_select" class="form-select" required>
                <option value="" selected disabled>Select a provider...</option>
                <?php foreach ($providers as $p): ?>
                  <option value="<?= htmlspecialchars($p['name']) ?>" data-type="<?= htmlspecialchars($p['type']) ?>">
                    <?= htmlspecialchars($p['name']) ?> (<?= htmlspecialchars($p['type']) ?>)
                  </option>
                <?php endforeach; ?>
                <option value="__custom__">Other (type manually)</option>
              </select>
            </div>

            <div class="col-md-6">
              <label class="form-label">Hospital / Clinic Name</label>
              <input type="text" id="providerName" name="provider_name" class="form-control" readonly required>
            </div>

            <div class="col-md-4">
              <label class="form-label">Type</label>
              <select id="providerType" class="form-select" disabled>
                <option value="Hospital">Hospital</option>
                <option value="Clinic" selected>Clinic</option>
                <option value="GP">GP</option>
                <option value="Pharmacy">Pharmacy</option>
                <option value="Other">Other</option>
              </select>
              <input type="hidden" name="provider_type" id="providerTypeHidden" value="Clinic">
            </div>

            <div class="col-md-4">
              <label class="form-label">Date</label>
              <input type="date" id="apptDate" name="appointment_date" class="form-control" min="<?= date('Y-m-d') ?>" required>
            </div>

            <div class="col-md-4">
              <label class="form-label">Time</label>
              <input type="time" id="apptTime" name="appointment_time" class="form-control" required>
            </div>

            <div class="col-md-6">
              <label class="form-label">Reason</label>
              <input type="text" name="reason" class="form-control" placeholder="e.g. BP check">
            </div>

            <div class="col-12">
              <label class="form-label">Notes</label>
              <textarea name="notes" class="form-control" rows="3" placeholder="Optional notes..."></textarea>
            </div>

            <div class="col-12 d-flex gap-2 align-items-center">
              <button type="submit" class="btn btn-gradient px-4">
                <i class="bi bi-calendar-plus me-2"></i>Book Appointment
              </button>
              <span id="apptMsg" class="text-muted"></span>
            </div>
          </form>
        </div>

        <div class="card p-4 shadow-sm border-0">
          <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
            <h4 class="fw-bold text-purple mb-0">Your Appointments</h4>
            <span class="badge badge-soft rounded-pill px-3 py-2">Personal tracking only</span>
          </div>

          <?php if (empty($appointments)): ?>
            <p class="text-muted mb-0 text-center">No appointments yet. Book one above.</p>
          <?php else: ?>
            <div class="table-responsive">
              <table class="table align-middle text-center">
                <thead class="table-light">
                  <tr>
                    <th>Provider</th>
                    <th>Type</th>
                    <th>Date</th>
                    <th>Time</th>
                    <th>Status</th>
                    <th>Reason</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach ($appointments as $a): ?>
                    <?php
                      $status = $a['status'] ?? 'Booked';
                      $badgeClass = ($status === 'Booked') ? 'bg-success' : (($status === 'Cancelled') ? 'bg-secondary' : 'bg-info');
                    ?>
                    <tr>
                      <td><?= htmlspecialchars($a['provider_name']) ?></td>
                      <td><?= htmlspecialchars($a['provider_type']) ?></td>
                      <td><?= htmlspecialchars($a['appointment_date']) ?></td>
                      <td><?= htmlspecialchars(substr((string)$a['appointment_time'], 0, 5)) ?></td>
                      <td><span class="badge <?= $badgeClass ?>"><?= htmlspecialchars($status) ?></span></td>
                      <td><?= htmlspecialchars($a['reason'] ?? '') ?></td>
                      <td>
                        <?php if ($status === 'Booked'): ?>
                          <button
                            type="button"
                            class="btn btn-outline-danger btn-sm cancel-btn"
                            data-id="<?= (int)$a['id'] ?>"
                          >
                            <i class="bi bi-x-circle me-1"></i>Cancel
                          </button>
                        <?php else: ?>
                          <span class="text-muted">—</span>
                        <?php endif; ?>
                      </td>
                    </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </div>
          <?php endif; ?>
        </div>

      </div>
    </main>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="script.js?v=5"></script>
</body>
</html>