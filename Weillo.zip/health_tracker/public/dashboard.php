<?php
session_start();
require_once __DIR__ . '/../config/Database.php';
require_once __DIR__ . '/../controllers/EntryController.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$db = (new Database())->getConnection();
$entryController = new EntryController($db);
$userId = (int)$_SESSION['user_id'];

date_default_timezone_set('Europe/London');

$todayYmd       = date('Y-m-d');
$todayFormatted = date('l, F j, Y');
$todayEntry     = $entryController->getByDate($userId, $todayYmd);

$entries = $entryController->list(['user_id' => $userId]);
$rows = is_array($entries) ? ($entries['body'] ?? $entries) : [];

function valOrDash($arr, $key) {
    return isset($arr[$key]) && $arr[$key] !== '' ? htmlspecialchars((string)$arr[$key]) : '--';
}

function calculateHealthScore(array $entry, ?float $goalWeightKg = null): array
{
    $weight = isset($entry['weight']) && $entry['weight'] !== '' ? (float)$entry['weight'] : null;
    $sys    = isset($entry['blood_pressure_sys']) && $entry['blood_pressure_sys'] !== '' ? (int)$entry['blood_pressure_sys'] : null;
    $dia    = isset($entry['blood_pressure_dia']) && $entry['blood_pressure_dia'] !== '' ? (int)$entry['blood_pressure_dia'] : null;
    $sleep  = isset($entry['sleep_hours']) && $entry['sleep_hours'] !== '' ? (float)$entry['sleep_hours'] : null;

    $sleepScore = null;
    if ($sleep !== null) {
        if ($sleep >= 7 && $sleep <= 9) {
            $sleepScore = 100;
        } else {
            $diff = abs($sleep - 8.0);
            $sleepScore = max(0, 100 - $diff * 20);
        }
    }

    $bpScore = null;
    if ($sys !== null && $dia !== null) {
        $targetSys = 115;
        $targetDia = 75;
        $sysError = abs($sys - $targetSys);
        $diaError = abs($dia - $targetDia);
        $bpScore = 100 - ($sysError * 1.5 + $diaError * 2.0);
        if ($bpScore < 0) $bpScore = 0;
    }

    $weightScore = null;
    if ($weight !== null && $goalWeightKg !== null && $goalWeightKg > 0) {
        $delta = abs($weight - $goalWeightKg);
        $weightScore = max(0, 100 - $delta * 5);
    }

    $sleepWeight  = ($sleepScore !== null)  ? 0.4 : 0.0;
    $bpWeight     = ($bpScore !== null)     ? 0.4 : 0.0;
    $weightWeight = ($weightScore !== null) ? 0.2 : 0.0;

    $weightSum = $sleepWeight + $bpWeight + $weightWeight;
    if ($weightSum <= 0) {
        return ['score' => null, 'label' => 'No data'];
    }

    $rawScore = 0;
    if ($sleepScore !== null)  $rawScore += $sleepScore * $sleepWeight;
    if ($bpScore !== null)     $rawScore += $bpScore * $bpWeight;
    if ($weightScore !== null) $rawScore += $weightScore * $weightWeight;

    $rawScore = $rawScore / $weightSum;
    $score = (int) round($rawScore);

    if ($score >= 80) {
        $label = 'Great';
    } elseif ($score >= 60) {
        $label = 'Okay';
    } else {
        $label = 'Needs attention';
    }

    return ['score' => $score, 'label' => $label];
}

$goalWeightKg = 70.0;
$todayHealth  = $todayEntry ? calculateHealthScore($todayEntry, $goalWeightKg) : ['score' => null, 'label' => 'No data'];

$self = basename(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Health Tracker</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
  <link rel="stylesheet" href="style.css?v=design-refresh-1">
</head>

<body>
<div class="app-shell d-flex">
  <?php include __DIR__ . '/sidebar.php'; ?>

  <div class="flex-grow-1">
    <div class="topbar container py-3 d-flex align-items-center justify-content-between">
      <button class="btn btn-outline-secondary d-inline-flex align-items-center gap-2 d-md-none" id="sidebarToggle">
        <i class="bi bi-list"></i> Menu
      </button>
      <div class="ms-auto">
        <p class="fw-semibold text-purple fs-5 mb-0">
          <i class="bi bi-calendar3 me-2"></i>Today: <?= htmlspecialchars($todayFormatted) ?>
        </p>
      </div>
    </div>

    <main id="content">
      <div class="container pb-5">
        <div class="row g-4 mb-5">
          <div class="col-md-3">
            <div class="card metric-card text-center">
              <div class="icon bg-pink-light"><i class="bi bi-person"></i></div>
              <h5>Weight</h5>
              <p class="metric-value"><?= $todayEntry ? valOrDash($todayEntry, 'weight') : '--' ?> <span>kg</span></p>
            </div>
          </div>

          <div class="col-md-3">
            <div class="card metric-card text-center">
              <div class="icon bg-green-light"><i class="bi bi-moon"></i></div>
              <h5>Sleep</h5>
              <p class="metric-value"><?= $todayEntry ? valOrDash($todayEntry, 'sleep_hours') : '--' ?> <span>hours</span></p>
            </div>
          </div>

          <div class="col-md-3">
            <div class="card metric-card text-center">
              <div class="icon bg-purple-light"><i class="bi bi-activity"></i></div>
              <h5>Blood Pressure</h5>
              <p class="metric-value">
                <?php if ($todayEntry): ?>
                  <?= valOrDash($todayEntry, 'blood_pressure_sys') ?>/<?= valOrDash($todayEntry, 'blood_pressure_dia') ?> <span>mmHg</span>
                <?php else: ?>
                  -- <span>mmHg</span>
                <?php endif; ?>
              </p>
            </div>
          </div>

          <div class="col-md-3">
            <div class="card metric-card text-center">
              <div class="icon bg-blue-light"><i class="bi bi-journal-text"></i></div>
              <h5>Notes</h5>
              <p class="metric-value"><?= $todayEntry ? valOrDash($todayEntry, 'notes') : '--' ?></p>
            </div>
          </div>

          <div class="col-md-3">
            <div class="card metric-card text-center">
              <div class="icon bg-orange-light"><i class="bi bi-heart-pulse"></i></div>
              <h5>Health Score</h5>
              <?php if ($todayHealth['score'] !== null): ?>
                <p class="metric-value">
                  <?= htmlspecialchars((string)$todayHealth['score']) ?> <span>/ 100</span>
                </p>
                <p class="text-muted mb-0"><?= htmlspecialchars($todayHealth['label']) ?></p>
              <?php else: ?>
                <p class="metric-value">--</p>
                <p class="text-muted mb-0">No data</p>
              <?php endif; ?>
            </div>
          </div>
        </div>

        <div class="text-center mb-5 d-flex justify-content-center gap-3 flex-wrap">
          <?php if (!$todayEntry): ?>
            <button class="btn btn-gradient equal-btn" id="addBtn" data-bs-toggle="modal" data-bs-target="#recordModal">
              <i class="bi bi-plus-circle me-2"></i>Record Today’s Health Data
            </button>
          <?php else: ?>
            <button class="btn btn-gradient equal-btn" id="editBtn">
              <i class="bi bi-pencil-square me-2"></i>Update Today’s Data
            </button>
          <?php endif; ?>
        </div>

        <div class="card p-4 shadow-sm border-0">
          <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
            <h4 class="fw-bold mb-0 text-purple">Recent Readings</h4>
            <span class="badge badge-soft rounded-pill px-3 py-2">Latest health entries</span>
          </div>

          <?php if (!empty($rows)): ?>
            <div class="table-responsive">
              <table class="table align-middle text-center">
                <thead class="table-light">
                  <tr>
                    <th>Date</th>
                    <th>Weight (kg)</th>
                    <th>BP (Sys/Dia)</th>
                    <th>Sleep (hrs)</th>
                    <th>Notes</th>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach ($rows as $row): ?>
                  <tr>
                    <td><?= htmlspecialchars($row['entry_date']) ?></td>
                    <td><?= htmlspecialchars(number_format((float)$row['weight'], 2)) ?></td>
                    <td><?= htmlspecialchars($row['blood_pressure_sys']) ?>/<?= htmlspecialchars($row['blood_pressure_dia']) ?></td>
                    <td><?= htmlspecialchars(number_format((float)$row['sleep_hours'], 2)) ?></td>
                    <td><?= htmlspecialchars($row['notes']) ?></td>
                  </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </div>
          <?php else: ?>
            <p class="text-center text-muted mb-0">No readings yet. Add your first record to get started!</p>
          <?php endif; ?>
        </div>
      </div>
    </main>
  </div>
</div>

<div class="modal fade" id="recordModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog">
    <form id="recordForm" class="modal-content">
      <div class="modal-header text-white" style="background: linear-gradient(90deg, #7b4eff, #b15cff);">
        <h5 class="modal-title">Add Today’s Health Record</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div class="mb-3">
          <label class="form-label">Weight (kg)</label>
          <input type="number" step="0.1" name="weight" class="form-control" required>
        </div>
        <div class="mb-3 row">
          <div class="col">
            <label class="form-label">BP Systolic</label>
            <input type="number" name="blood_pressure_sys" class="form-control" required>
          </div>
          <div class="col">
            <label class="form-label">BP Diastolic</label>
            <input type="number" name="blood_pressure_dia" class="form-control" required>
          </div>
        </div>
        <div class="mb-3">
          <label class="form-label">Sleep Hours</label>
          <input type="number" step="0.1" name="sleep_hours" class="form-control" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Notes</label>
          <textarea name="notes" class="form-control" rows="3" required></textarea>
        </div>
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-gradient px-4">Save Record</button>
      </div>
    </form>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.getElementById("recordForm").addEventListener("submit", async function(e) {
  e.preventDefault();
  const formData = new FormData(this);
  const response = await fetch("save_record.php", { method: "POST", body: formData });
  if (response.ok) {
    bootstrap.Modal.getInstance(document.getElementById("recordModal"))?.hide();
    location.reload();
  } else {
    alert("❌ Error saving record!");
  }
});

document.getElementById("addBtn")?.addEventListener("click", () => {
  document.querySelector('#recordModal .modal-title').textContent = "Add Today’s Health Record";
  document.querySelector('#recordModal .btn-gradient').textContent = "Save Record";
  document.getElementById("recordForm").reset();
});

document.getElementById("editBtn")?.addEventListener("click", () => {
  const entry = <?= json_encode($todayEntry ?: null); ?>;
  if (!entry) return;
  document.querySelector('[name="weight"]').value = entry.weight ?? '';
  document.querySelector('[name="blood_pressure_sys"]').value = entry.blood_pressure_sys ?? '';
  document.querySelector('[name="blood_pressure_dia"]').value = entry.blood_pressure_dia ?? '';
  document.querySelector('[name="sleep_hours"]').value = entry.sleep_hours ?? '';
  document.querySelector('[name="notes"]').value = entry.notes ?? '';
  document.querySelector('#recordModal .modal-title').textContent = 'Update Today’s Health Record';
  document.querySelector('#recordModal .btn-gradient').textContent = 'Update Record';
  new bootstrap.Modal(document.getElementById('recordModal')).show();
});

document.getElementById('sidebarToggle')?.addEventListener('click', () => {
  document.getElementById('sidebar').classList.toggle('open');
});
</script>
</body>
</html>