<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$self = basename(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Ask Weillo</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
  <link rel="stylesheet" href="style.css?v=design-refresh-1">
</head>
<body>
<div class="app-shell d-flex">
  <?php include __DIR__ . '/sidebar.php'; ?>

  <div class="flex-grow-1">
    <div class="topbar container py-3 d-flex align-items-center justify-content-between">
      <button class="btn btn-outline-secondary d-inline-flex align-items-center gap-2 d-md-none" id="sidebarToggle">
        <i class="bi bi-list"></i> Menu
      </button>
      <div class="ms-auto">
        <p class="fw-semibold text-purple fs-5 mb-0">
          <i class="bi bi-chat-dots me-2"></i>Ask Weillo
        </p>
      </div>
    </div>

    <main id="content">
      <div class="container pb-5">
        <div class="card chat-shell-card p-4 shadow-sm border-0">
          <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
            <div>
              <h4 class="fw-bold text-purple mb-1">Ask Weillo</h4>
              <p class="text-muted mb-0 small">Get simple wellness guidance about sleep, blood pressure, stress, weight, and more.</p>
            </div>
            <button id="clearBtn" class="btn btn-outline-secondary btn-sm">
              <i class="bi bi-trash3 me-1"></i> Clear Chat
            </button>
          </div>

          <div class="mb-3 d-flex flex-wrap gap-2">
            <button type="button" class="btn quick-question" data-question="How can I improve my sleep?">Improve my sleep</button>
            <button type="button" class="btn quick-question" data-question="What should I do if my blood pressure is high?">Blood pressure advice</button>
            <button type="button" class="btn quick-question" data-question="How can I improve my health score?">Improve health score</button>
            <button type="button" class="btn quick-question" data-question="Why do I feel tired all the time?">Why am I tired?</button>
            <button type="button" class="btn quick-question" data-question="How can I reduce stress?">Reduce stress</button>
            <button type="button" class="btn quick-question" data-question="What are some healthy eating tips?">Healthy eating tips</button>
          </div>

          <div id="chatBox" class="chat-box border rounded-4 p-3 mb-3"></div>

          <div class="row g-2 align-items-end">
            <div class="col-12 col-md-10">
              <label for="prompt" class="form-label fw-semibold">Your question</label>
              <textarea id="prompt" class="form-control" rows="2" placeholder="Type your question..."></textarea>
            </div>
            <div class="col-12 col-md-2 d-grid">
              <button id="sendBtn" class="btn btn-gradient h-100 py-3">
                <i class="bi bi-send me-1"></i> Send
              </button>
            </div>
          </div>

          <div class="mt-3 text-muted small">
            Weillo gives general health tracking guidance and does not replace medical advice.
          </div>
        </div>
      </div>
    </main>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
  document.getElementById('sidebarToggle')?.addEventListener('click', () => {
    document.getElementById('sidebar').classList.toggle('open');
  });

  const CHAT_KEY = 'weillo_chat_history_user_<?= (int)$_SESSION['user_id'] ?>';
  const chatBox = document.getElementById('chatBox');
  const promptEl = document.getElementById('prompt');
  const sendBtn = document.getElementById('sendBtn');
  const clearBtn = document.getElementById('clearBtn');
  const quickButtons = document.querySelectorAll('.quick-question');
  let messages = loadMessages();

  function loadMessages() {
    try {
      const saved = localStorage.getItem(CHAT_KEY);
      return saved ? JSON.parse(saved) : [];
    } catch (e) {
      return [];
    }
  }

  function saveMessages() {
    localStorage.setItem(CHAT_KEY, JSON.stringify(messages));
  }

  function renderMessages() {
    chatBox.innerHTML = '';

    if (!messages.length) {
      chatBox.innerHTML = `
        <div class="text-muted small">
          Ask about your health data, habits, sleep, blood pressure, weight trends, stress, and more.
        </div>
      `;
      return;
    }

    messages.forEach(msg => {
      const wrap = document.createElement('div');
      wrap.className = 'mb-2 d-flex ' + (msg.role === 'user' ? 'justify-content-end' : 'justify-content-start');

      const bubble = document.createElement('div');
      bubble.className = 'p-2 px-3 rounded-4 ' + (msg.role === 'user' ? 'chat-bubble-user' : 'chat-bubble-assistant');
      bubble.style.maxWidth = '85%';
      bubble.style.whiteSpace = 'pre-wrap';
      bubble.innerText = msg.text;

      wrap.appendChild(bubble);
      chatBox.appendChild(wrap);
    });

    chatBox.scrollTop = chatBox.scrollHeight;
  }

  function addBubble(role, text) {
    messages.push({ role, text });
    saveMessages();
    renderMessages();
  }

  async function sendQuestion(questionText = null) {
    const prompt = questionText ?? promptEl.value.trim();
    if (!prompt) return;

    addBubble('user', prompt);
    promptEl.value = '';
    sendBtn.disabled = true;
    sendBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Thinking...';

    try {
      const res = await fetch('ask_api.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt })
      });

      const rawText = await res.text();
      let data;

      try {
        data = JSON.parse(rawText);
      } catch (err) {
        addBubble('assistant', 'Invalid server response: ' + rawText);
        return;
      }

      if (!res.ok) {
        addBubble('assistant', data?.error || 'Something went wrong.');
      } else {
        addBubble('assistant', data.answer || '(No answer)');
      }
    } catch (e) {
      addBubble('assistant', 'Network error. Please try again.');
    } finally {
      sendBtn.disabled = false;
      sendBtn.innerHTML = '<i class="bi bi-send me-1"></i> Send';
      promptEl.focus();
    }
  }

  sendBtn.addEventListener('click', () => sendQuestion());

  promptEl.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendQuestion();
    }
  });

  quickButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const question = btn.dataset.question || '';
      sendQuestion(question);
    });
  });

  clearBtn.addEventListener('click', () => {
    if (!confirm('Clear this conversation?')) return;
    messages = [];
    localStorage.removeItem(CHAT_KEY);
    renderMessages();
  });

  renderMessages();
</script>
</body>
</html>