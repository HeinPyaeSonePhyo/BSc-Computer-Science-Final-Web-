<?php
session_start();
require_once __DIR__ . '/../config/Database.php';
require_once __DIR__ . '/../controllers/AuthController.php';

$db = (new Database())->getConnection();
$auth = new AuthController($db);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $response = $auth->login([
        'email' => $_POST['email'] ?? '',
        'password' => $_POST['password'] ?? ''
    ]);

    if ($response['status'] === 200) {
        $_SESSION['user_id'] = $response['body']['user_id'];
        header("Location: dashboard.php");
        exit;
    } else {
        $error = $response['body']['error'] ?? 'Invalid credentials.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Login | Weillo</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
  <link rel="stylesheet" href="style.css?v=design-refresh-1">
</head>
<body class="bg-weillo">
  <div class="container py-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
      <div>
        <h1 class="fw-bold text-purple mb-1">Weillo</h1>
        <p class="text-muted mb-0">Monitor your wellness journey</p>
      </div>
      
    </div>

    <div class="row justify-content-center">
      <div class="col-lg-5 col-md-6">
        <div class="card auth-card shadow-sm">
          <div class="card-header auth-header d-flex align-items-center">
            <i class="bi bi-box-arrow-in-right me-2"></i>
            <span class="fw-semibold">Welcome Back</span>
          </div>

          <?php if (!empty($error)): ?>
            <div class="alert alert-danger m-3"><?= htmlspecialchars($error) ?></div>
          <?php endif; ?>

          <div class="card-body p-4">
            <form method="POST" novalidate>
              <div class="mb-3">
                <label class="form-label">Email</label>
                <input type="email" name="email" class="form-control" required>
              </div>

              <div class="mb-3">
                <label class="form-label">Password</label>
                <input type="password" name="password" class="form-control" required>
              </div>

              <button class="btn btn-gradient w-100 py-2">
                <i class="bi bi-door-open me-2"></i>Login
              </button>
            </form>

            <p class="text-center mt-3 mb-0">
              Don’t have an account?
              <a href="register.php" class="purple-link">Register here</a>.
            </p>
          </div>
        </div>
      </div>
    </div>
  </div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>