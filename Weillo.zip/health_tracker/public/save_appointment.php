<?php
session_start();

require_once __DIR__ . '/../config/Database.php';
require_once __DIR__ . '/../controllers/AppointmentController.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $_SESSION['appointment_error'] = 'Invalid request method.';
    header('Location: treatment.php');
    exit;
}

$data = [
    'user_id'          => (int)$_SESSION['user_id'],
    'provider_name'    => trim($_POST['provider_name'] ?? ''),
    'provider_type'    => trim($_POST['provider_type'] ?? 'Clinic'),
    'appointment_date' => trim($_POST['appointment_date'] ?? ''),
    'appointment_time' => trim($_POST['appointment_time'] ?? ''),
    'reason'           => trim($_POST['reason'] ?? ''),
    'notes'            => trim($_POST['notes'] ?? ''),
];

if ($data['provider_name'] === '' || $data['appointment_date'] === '' || $data['appointment_time'] === '') {
    $_SESSION['appointment_error'] = 'Please fill in all required appointment fields.';
    header('Location: treatment.php');
    exit;
}

try {
    $db = (new Database())->getConnection();
    $controller = new AppointmentController($db);
    $res = $controller->create($data);

    if (($res['status'] ?? 500) >= 200 && ($res['status'] ?? 500) < 300) {
        $_SESSION['appointment_success'] = $res['body']['message'] ?? 'Appointment booked successfully.';
    } else {
        $_SESSION['appointment_error'] = $res['body']['error'] ?? 'Failed to book appointment.';
    }
} catch (Throwable $e) {
    $_SESSION['appointment_error'] = 'System error: ' . $e->getMessage();
}

header('Location: treatment.php');
exit;