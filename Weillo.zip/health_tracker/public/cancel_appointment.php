<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../config/Database.php';
require_once __DIR__ . '/../controllers/AppointmentController.php';

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$appointmentId = isset($_POST['appointment_id']) ? (int)$_POST['appointment_id'] : 0;

if ($appointmentId <= 0) {
    http_response_code(400);
    echo json_encode(['error' => 'appointment_id is required']);
    exit;
}

try {
    $db = (new Database())->getConnection();
    $controller = new AppointmentController($db);

    $res = $controller->cancel((int)$_SESSION['user_id'], $appointmentId);

    http_response_code($res['status'] ?? 200);
    echo json_encode($res['body'] ?? []);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['error' => 'System error: ' . $e->getMessage()]);
}