<?php
session_start();
require_once __DIR__ . '/../config/Database.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$db = (new Database())->getConnection();
$userId = (int)$_SESSION['user_id'];

$stmt = $db->prepare("
    SELECT username, first_name, last_name, gender, dob, created_at
    FROM users
    WHERE id = :id
    LIMIT 1
");
$stmt->execute([':id' => $userId]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    echo "❌ User not found.";
    exit;
}

$self = basename(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Profile | Weillo</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
  <link rel="stylesheet" href="style.css?v=design-refresh-1">
</head>

<body>
<div class="app-shell d-flex">
  <?php include __DIR__ . '/sidebar.php'; ?>

  <div class="flex-grow-1">
    <div class="topbar container py-3 d-flex align-items-center justify-content-between">
      <button class="btn btn-outline-secondary d-inline-flex align-items-center gap-2 d-md-none" id="sidebarToggle">
        <i class="bi bi-list"></i> Menu
      </button>
      <h4 class="fw-bold text-purple mb-0">My Profile</h4>
    </div>

    <main id="content">
      <div class="container pb-5">
        <div class="card p-4 shadow-sm border-0" style="max-width: 760px; margin: 0 auto;">
          <div class="d-flex align-items-center mb-4">
            <div class="icon bg-purple-light me-3" style="width:60px; height:60px; border-radius:16px; display:flex; align-items:center; justify-content:center;">
              <i class="bi bi-person-fill" style="font-size:28px; color:var(--purple);"></i>
            </div>
            <div>
              <h4 class="fw-bold mb-0"><?= htmlspecialchars($user['username'] ?: 'Unnamed User') ?></h4>
              <p class="text-muted mb-0">Member since <?= htmlspecialchars(date('F j, Y', strtotime($user['created_at']))) ?></p>
            </div>
          </div>

          <table class="table mb-4">
            <tbody>
              <tr>
                <th class="text-muted" width="30%">First Name</th>
                <td><?= htmlspecialchars($user['first_name'] ?: '--') ?></td>
              </tr>
              <tr>
                <th class="text-muted">Last Name</th>
                <td><?= htmlspecialchars($user['last_name'] ?: '--') ?></td>
              </tr>
              <tr>
                <th class="text-muted">Gender</th>
                <td><?= htmlspecialchars($user['gender'] ?: '--') ?></td>
              </tr>
              <tr>
                <th class="text-muted">Date of Birth</th>
                <td><?= $user['dob'] ? htmlspecialchars(date('F j, Y', strtotime($user['dob']))) : '--' ?></td>
              </tr>
            </tbody>
          </table>

          <div class="text-center">
            <button class="btn btn-gradient px-4" id="editProfileBtn">
              <i class="bi bi-pencil-square me-2"></i>Edit Profile
            </button>
          </div>
        </div>
      </div>
    </main>
  </div>
</div>

<div class="modal fade" id="editProfileModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog">
    <form id="editProfileForm" class="modal-content">
      <div class="modal-header text-white" style="background: linear-gradient(90deg, #7b4eff, #b15cff);">
        <h5 class="modal-title">Edit Profile</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>

      <div class="modal-body">
        <div class="mb-3">
          <label class="form-label">First Name</label>
          <input type="text" name="first_name" class="form-control" value="<?= htmlspecialchars($user['first_name'] ?? '') ?>">
        </div>

        <div class="mb-3">
          <label class="form-label">Last Name</label>
          <input type="text" name="last_name" class="form-control" value="<?= htmlspecialchars($user['last_name'] ?? '') ?>">
        </div>

        <div class="mb-3">
          <label class="form-label">Gender</label>
          <select name="gender" class="form-select themed-select">
            <option value="">Select gender</option>
            <option value="Male" <?= ($user['gender'] === 'Male') ? 'selected' : '' ?>>Male</option>
            <option value="Female" <?= ($user['gender'] === 'Female') ? 'selected' : '' ?>>Female</option>
            <option value="Other" <?= ($user['gender'] === 'Other') ? 'selected' : '' ?>>Other</option>
          </select>
        </div>

        <div class="mb-3">
          <label class="form-label">Date of Birth</label>
          <input type="date" name="dob" class="form-control" value="<?= htmlspecialchars($user['dob'] ?? '') ?>">
        </div>

        <hr>

        <div class="mb-2">
          <label class="form-label">Current Password</label>
          <input type="password" name="current_password" class="form-control" required>
          <div class="form-text">Enter your password to confirm profile changes.</div>
        </div>
      </div>

      <div class="modal-footer">
        <button type="submit" class="btn btn-gradient px-4">Save Changes</button>
      </div>
    </form>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
  const sidebar = document.getElementById('sidebar');
  const toggle = document.getElementById('sidebarToggle');
  if (toggle) {
    toggle.addEventListener('click', () => sidebar.classList.toggle('open'));
  }

  const modalEl = document.getElementById('editProfileModal');
  const modal = new bootstrap.Modal(modalEl);

  document.getElementById('editProfileBtn')?.addEventListener('click', () => {
    modal.show();
  });

  document.getElementById('editProfileForm').addEventListener('submit', async function(e) {
    e.preventDefault();

    const formData = new FormData(this);

    try {
      const response = await fetch('update_profile.php', {
        method: 'POST',
        body: formData
      });

      const result = await response.json();

      if (result.success) {
        modal.hide();
        alert('✅ Profile updated successfully!');
        location.reload();
      } else {
        alert('❌ ' + (result.error || 'Error updating profile.'));
      }
    } catch (error) {
      alert('❌ Network error. Please try again.');
    }
  });
</script>
</body>
</html>