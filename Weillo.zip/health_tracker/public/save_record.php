<?php
session_start();
require_once __DIR__ . '/../config/Database.php';
require_once __DIR__ . '/../controllers/EntryController.php';


header('Content-Type: application/json');

// --- Auth check ---
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}


date_default_timezone_set('Europe/London');


try {
    // Database + controller
    $db = (new Database())->getConnection();
    $entryController = new EntryController($db);
    $userId = (int)$_SESSION['user_id'];
    $today  = date('Y-m-d');

    // --- Sanitize inputs ---
    $weight = isset($_POST['weight']) ? (float)$_POST['weight'] : null;
    $sys    = isset($_POST['blood_pressure_sys']) ? (int)$_POST['blood_pressure_sys'] : null;
    $dia    = isset($_POST['blood_pressure_dia']) ? (int)$_POST['blood_pressure_dia'] : null;
    $sleep  = isset($_POST['sleep_hours']) ? (float)$_POST['sleep_hours'] : null;
    $notes  = isset($_POST['notes']) ? trim($_POST['notes']) : '';

    $entryData = [
        'user_id' => $userId,
        'entry_date' => $today,
        'weight' => $weight,
        'blood_pressure_sys' => $sys,
        'blood_pressure_dia' => $dia,
        'sleep_hours' => $sleep,
        'notes' => $notes
    ];

    // --- Check if an entry for today already exists ---
    $existing = $entryController->getByDate($userId, $today);

    if ($existing && isset($existing['id'])) {
        // Update today's entry
        $entryController->update((int)$existing['id'], $entryData);
        echo json_encode([
            'status' => 'updated',
            'message' => '✅ Entry updated successfully.',
            'date' => $today
        ]);
    } else {
        // Create new entry for today
        $entryController->create($entryData);
        echo json_encode([
            'status' => 'created',
            'message' => '✅ Entry created successfully.',
            'date' => $today
        ]);
    }

} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'error' => 'Server error',
        'detail' => $e->getMessage()
    ]);
}
