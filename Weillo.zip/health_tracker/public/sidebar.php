<?php
if (!isset($self)) {
    $self = basename(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));
}

if (!function_exists('isActiveAny')) {
    function isActiveAny(array $pages, string $self): string {
        return in_array($self, $pages, true) ? 'active' : '';
    }
}
?>

<aside id="sidebar" class="weillo-sidebar">
  <div class="brand">
    <span class="brand-logo">Weillo</span>
  </div>

  <nav class="nav-list">
    <a href="profile.php" class="nav-item <?= isActiveAny(['profile.php'], $self) ?>">
      <i class="bi bi-person-circle"></i><span>Profile</span>
    </a>

    <a href="dashboard.php" class="nav-item <?= isActiveAny(['index.php', 'dashboard.php'], $self) ?>">
      <i class="bi bi-speedometer2"></i><span>Dashboard</span>
    </a>

    <a href="monthly.php" class="nav-item <?= isActiveAny(['monthly.php'], $self) ?>">
      <i class="bi bi-graph-up"></i><span>Monthly Graph</span>
    </a>

    <a href="ask.php" class="nav-item <?= isActiveAny(['ask.php'], $self) ?>">
      <i class="bi bi-chat-dots"></i><span>Ask Weillo</span>
    </a>

    <a href="treatment.php" class="nav-item <?= isActiveAny(['treatment.php'], $self) ?>">
      <i class="bi bi-hospital"></i><span>Get Treatment</span>
    </a>
  </nav>

  <div class="nav-footer">
    <a href="logout.php" class="nav-item danger">
      <i class="bi bi-box-arrow-right"></i><span>Logout</span>
    </a>
  </div>
</aside>