<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$raw = file_get_contents('php://input');
$body = json_decode($raw, true);

$prompt = isset($body['prompt']) ? trim((string)$body['prompt']) : '';
if ($prompt === '') {
    http_response_code(400);
    echo json_encode(['error' => 'Prompt is required']);
    exit;
}

$demoMode = (getenv('WEILLO_DEMO_AI') === '1');

function demoWeilloAnswer(string $prompt): string
{
    $p = strtolower(trim($prompt));

    // ---- Sleep ----
    if (
        str_contains($p, "can't sleep") ||
        str_contains($p, "cannot sleep") ||
        str_contains($p, "not sleeping") ||
        str_contains($p, "insomnia")
    ) {
        return "Demo Weillo: Difficulty sleeping can happen for many reasons, including stress, anxiety, caffeine, screen time before bed, or an irregular sleep routine. Try going to bed at the same time each night, avoiding caffeine in the evening, and keeping your room quiet and dark. If this continues often, it may be helpful to speak to a healthcare professional.";
    }

    if (
        str_contains($p, 'sleep better') ||
        str_contains($p, 'improve sleep') ||
        str_contains($p, 'better sleep')
    ) {
        return "Demo Weillo: To improve sleep, try building a simple bedtime routine. Go to sleep and wake up at similar times each day, avoid screens before bed, and keep your room cool and comfortable. Reducing caffeine late in the day can also make a big difference.";
    }

    if (str_contains($p, 'sleep')) {
        return "Demo Weillo: Most adults usually need around 7 to 9 hours of sleep each night. Low sleep can affect your mood, energy, focus, and even blood pressure. A regular sleep schedule, less late-night screen use, and a relaxing bedtime routine are good first steps.";
    }

    // ---- Blood Pressure ----
    if (
        str_contains($p, 'high blood pressure') ||
        str_contains($p, 'bp high') ||
        str_contains($p, 'my blood pressure is high')
    ) {
        return "Demo Weillo: High blood pressure can sometimes be linked to stress, too much salt, poor sleep, lack of activity, or dehydration. Helpful habits include drinking enough water, reducing salty foods, being physically active, and getting regular rest. If your readings stay high, you should speak to a healthcare professional.";
    }

    if (
        str_contains($p, 'low blood pressure') ||
        str_contains($p, 'bp low')
    ) {
        return "Demo Weillo: Low blood pressure may sometimes be related to dehydration, not eating enough, or standing up too quickly. Drinking water, eating balanced meals, and tracking your symptoms can help. If you feel dizzy, weak, or faint often, it is a good idea to get medical advice.";
    }

    if (str_contains($p, 'blood pressure') || str_contains($p, 'bp')) {
        return "Demo Weillo: Blood pressure is affected by things like stress, sleep, hydration, activity level, and diet. To support healthy blood pressure, try regular walking, lower salt intake, enough sleep, and stress management. Repeated unusual readings should be checked by a healthcare professional.";
    }

    // ---- Health Score ----
    if (
        str_contains($p, 'health score low') ||
        str_contains($p, 'low health score') ||
        str_contains($p, 'why is my health score low')
    ) {
        return "Demo Weillo: A lower health score usually means one or more tracked areas, such as sleep, blood pressure, or weight, may need attention. Start by checking which value changed most recently. Improving sleep habits, tracking blood pressure more consistently, and keeping healthy routines can help raise the score over time.";
    }

    if (
        str_contains($p, 'improve health score') ||
        str_contains($p, 'increase health score')
    ) {
        return "Demo Weillo: To improve your health score, focus on the main health areas being tracked. Getting enough sleep, keeping blood pressure in a healthy range, staying active, and following steady daily habits are usually the most helpful steps. Small improvements done consistently often matter more than big short-term changes.";
    }

    if (str_contains($p, 'health score')) {
        return "Demo Weillo: Your Health Score gives a simple view of how your health tracking data is doing overall. It usually reflects things like sleep, blood pressure, and weight. If your score changes, it helps to look at which factor changed most and work on that first.";
    }

    // ---- Weight ----
    if (
        str_contains($p, 'lose weight') ||
        str_contains($p, 'weight loss')
    ) {
        return "Demo Weillo: Healthy weight loss usually works best through small consistent habits, such as balanced meals, regular activity, enough sleep, and tracking progress over time. It is usually more helpful to focus on long-term routines than fast short-term changes.";
    }

    if (
        str_contains($p, 'gain weight') ||
        str_contains($p, 'put on weight')
    ) {
        return "Demo Weillo: Healthy weight gain usually involves eating balanced meals more consistently, choosing nutrient-rich foods, and combining that with strength-based exercise where possible. If weight changes are unexpected, it may be worth discussing them with a healthcare professional.";
    }

    if (str_contains($p, 'weight')) {
        return "Demo Weillo: Weight can naturally go up and down from day to day, so weekly trends are usually more useful than single readings. Looking at your habits around food, movement, and sleep can help explain changes over time.";
    }

    // ---- Stress ----
    if (str_contains($p, 'stress') || str_contains($p, 'stressed')) {
        return "Demo Weillo: Stress can affect sleep, mood, energy, and even blood pressure. Helpful habits may include taking short breaks, going for a walk, practicing slow breathing, and keeping a regular sleep routine. If stress is becoming overwhelming, speaking to someone you trust or a professional may help.";
    }

    // ---- Anxiety ----
    if (str_contains($p, 'anxiety') || str_contains($p, 'anxious')) {
        return "Demo Weillo: Anxiety can make it harder to sleep, relax, or focus. Gentle breathing exercises, reducing caffeine, regular sleep, and short periods of movement can sometimes help. If anxiety is affecting daily life often, it would be sensible to seek support from a qualified professional.";
    }

    // ---- Exercise ----
    if (
        str_contains($p, 'exercise') ||
        str_contains($p, 'workout') ||
        str_contains($p, 'fitness')
    ) {
        return "Demo Weillo: Regular exercise can help with sleep, stress, weight management, and blood pressure. Even simple activities like walking, stretching, or light home workouts can make a difference. Consistency is usually more important than doing too much at once.";
    }

    // ---- Food / Diet ----
    if (
        str_contains($p, 'diet') ||
        str_contains($p, 'food') ||
        str_contains($p, 'eat healthy') ||
        str_contains($p, 'nutrition')
    ) {
        return "Demo Weillo: A healthy diet usually includes a balance of vegetables, fruit, protein, whole grains, and enough water. Reducing very salty, sugary, or highly processed foods may also support better energy and blood pressure. Small steady improvements are often easier to maintain than strict short-term diets.";
    }

    // ---- Hydration ----
    if (
        str_contains($p, 'water') ||
        str_contains($p, 'hydration') ||
        str_contains($p, 'dehydrated')
    ) {
        return "Demo Weillo: Staying hydrated is important for energy, concentration, and overall health. If you are not drinking enough water, you may feel tired, dizzy, or get headaches. Try drinking water regularly through the day rather than waiting until you feel very thirsty.";
    }

    // ---- Headache ----
    if (
        str_contains($p, 'headache') ||
        str_contains($p, 'headaches')
    ) {
        return "Demo Weillo: Headaches can sometimes be linked to dehydration, stress, poor sleep, or too much screen time. Drinking water, resting, and checking your sleep routine may help. If headaches are severe, frequent, or unusual for you, it would be a good idea to seek medical advice.";
    }

    // ---- Tiredness / Fatigue ----
    if (
        str_contains($p, 'tired') ||
        str_contains($p, 'fatigue') ||
        str_contains($p, 'low energy')
    ) {
        return "Demo Weillo: Feeling tired can be related to poor sleep, stress, dehydration, low activity, or not eating regularly. Looking at your sleep routine, hydration, meals, and daily habits may help identify the cause. If tiredness continues for a long time, it may be worth speaking to a healthcare professional.";
    }

    // ---- General Health ----
    if (
        str_contains($p, 'health') ||
        str_contains($p, 'wellbeing') ||
        str_contains($p, 'wellness')
    ) {
        return "Demo Weillo: Good health usually comes from steady daily habits, such as enough sleep, balanced meals, regular movement, hydration, and stress management. Tracking your health over time can help you notice patterns and make gradual improvements.";
    }

    return "Demo Weillo: I’m currently in demo mode, so my responses are limited. You can ask me about sleep, blood pressure, health score, weight, stress, anxiety, exercise, food, hydration, headaches, or general wellness.";
}

if ($demoMode) {
    echo json_encode([
        'answer' => demoWeilloAnswer($prompt),
        'mode'   => 'demo'
    ]);
    exit;
}

$apiKey = getenv('OPENAI_API_KEY');
if (!$apiKey) {
    echo json_encode([
        'answer' => demoWeilloAnswer($prompt) . "\n\n(Reason: Missing OPENAI_API_KEY — demo mode used.)",
        'mode'   => 'demo'
    ]);
    exit;
}

$model = getenv('OPENAI_MODEL') ?: 'gpt-5-mini';

$payload = [
    'model' => $model,
    'input' => [
        [
            'role' => 'system',
            'content' => [
                [
                    'type' => 'input_text',
                    'text' => "You are Weillo, a helpful health tracker assistant for a school project. " .
          "Be friendly, supportive, and practical. " .
          "Give complete but easy-to-understand answers. " .
          "Start with a short explanation, then give practical advice. " .
          "When useful, include bullet-style tips in plain text. " .
          "Do not diagnose medical conditions and do not claim to be a doctor." ]
            ]
        ],
        [
            'role' => 'user',
            'content' => [
                [
                    'type' => 'input_text',
                    'text' => $prompt
                ]
            ]
        ]
    ],
];

$ch = curl_init('https://api.openai.com/v1/responses');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_HTTPHEADER => [
        'Authorization: Bearer ' . $apiKey,
        'Content-Type: application/json',
    ],
    CURLOPT_POSTFIELDS => json_encode($payload),
    CURLOPT_TIMEOUT => 60,
]);

$result = curl_exec($ch);

if ($result === false) {
    $err = curl_error($ch);
    curl_close($ch);

    echo json_encode([
        'answer' => demoWeilloAnswer($prompt) . "\n\n(Reason: Network error — demo mode used.)",
        'mode'   => 'demo'
    ]);
    exit;
}

$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

$json = json_decode($result, true);

if ($httpCode === 429 || $httpCode === 402 || $httpCode === 401) {
    echo json_encode([
        'answer' => demoWeilloAnswer($prompt) . "\n\n(Reason: API quota/billing/limits — demo mode used.)",
        'mode'   => 'demo'
    ]);
    exit;
}

if ($httpCode < 200 || $httpCode >= 300) {
    $msg = $json['error']['message'] ?? 'OpenAI request failed';
    echo json_encode([
        'answer' => demoWeilloAnswer($prompt) . "\n\n(Reason: OpenAI error: {$msg} — demo mode used.)",
        'mode'   => 'demo'
    ]);
    exit;
}

$answer = '';

if (isset($json['output']) && is_array($json['output'])) {
    foreach ($json['output'] as $item) {
        if (!isset($item['content']) || !is_array($item['content'])) {
            continue;
        }

        foreach ($item['content'] as $c) {
            if (isset($c['text']) && is_string($c['text'])) {
                $answer .= $c['text'];
            }
        }
    }
}

$answer = trim($answer);

if ($answer === '' && isset($json['output_text']) && is_string($json['output_text'])) {
    $answer = trim($json['output_text']);
}

if ($answer === '') {
    $answer = "Sorry, I couldn't extract a response.";
}

echo json_encode([
    'answer' => $answer,
    'mode'   => 'openai'
]);