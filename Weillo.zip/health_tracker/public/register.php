<?php
session_start();
require_once __DIR__ . '/../config/Database.php';

$db = (new Database())->getConnection();

if (isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username        = trim($_POST['username'] ?? '');
    $email           = trim($_POST['email'] ?? '');
    $password        = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';
    $firstName       = trim($_POST['first_name'] ?? '');
    $lastName        = trim($_POST['last_name'] ?? '');
    $gender          = trim($_POST['gender'] ?? '');
    $dob             = trim($_POST['dob'] ?? '');

    if ($username === '' || $email === '' || $password === '' || $confirmPassword === '') {
        $error = 'Username, email, password, and confirm password are required.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } elseif (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters long.';
    } elseif ($password !== $confirmPassword) {
        $error = "Confirm password doesn't match the password you typed.";
    } elseif ($gender !== '' && !in_array($gender, ['Male', 'Female', 'Other'], true)) {
        $error = 'Invalid gender selected.';
    } else {
        try {
            $check = $db->prepare("SELECT id FROM users WHERE email = :email LIMIT 1");
            $check->execute([':email' => $email]);

            if ($check->fetch()) {
                $error = 'That email is already registered.';
            } else {
                $passwordHash = password_hash($password, PASSWORD_DEFAULT);

                $stmt = $db->prepare("
                    INSERT INTO users (username, email, password_hash, first_name, last_name, gender, dob)
                    VALUES (:username, :email, :password_hash, :first_name, :last_name, :gender, :dob)
                ");

                $stmt->execute([
                    ':username'      => $username,
                    ':email'         => $email,
                    ':password_hash' => $passwordHash,
                    ':first_name'    => $firstName !== '' ? $firstName : null,
                    ':last_name'     => $lastName !== '' ? $lastName : null,
                    ':gender'        => $gender !== '' ? $gender : null,
                    ':dob'           => $dob !== '' ? $dob : null,
                ]);

                $success = 'Account created successfully! You can now log in.';
            }
        } catch (PDOException $e) {
            $error = 'Registration failed. Please try again.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Register | Weillo</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
  <link rel="stylesheet" href="style.css?v=design-refresh-1">
</head>
<body class="bg-weillo">
  <div class="container py-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
      <div>
        <h1 class="fw-bold text-purple mb-1">Weillo</h1>
        <p class="text-muted mb-0">Start your wellness journey</p>
      </div>
      <div class="text-end d-none d-md-block">
        <p class="fw-semibold text-purple fs-5 mb-0">
          <i class="bi bi-person-plus me-2"></i>Create Account
        </p>
      </div>
    </div>

    <div class="row justify-content-center">
      <div class="col-lg-7 col-md-9">
        <div class="card auth-card shadow-sm border-0">
          <div class="card-header auth-header d-flex align-items-center">
            <i class="bi bi-person-badge me-2"></i>
            <span class="fw-semibold">Join Weillo</span>
          </div>

          <?php if (!empty($error)): ?>
            <div class="alert alert-danger m-3 mb-0"><?= htmlspecialchars($error) ?></div>
          <?php endif; ?>

          <?php if (!empty($success)): ?>
            <div class="alert alert-success m-3 mb-0">
              <?= htmlspecialchars($success) ?>
              <div class="mt-2">
                <a href="login.php" class="btn btn-sm btn-gradient">Go to Login</a>
              </div>
            </div>
          <?php endif; ?>

          <div class="card-body p-4">
            <div class="mb-3">
              <p class="text-muted mb-0">Create your account to start tracking your wellness journey with Weillo.</p>
            </div>

            <form method="POST" novalidate>
              <div class="row">
                <div class="col-md-6 mb-3">
                  <label class="form-label">First Name</label>
                  <input type="text" name="first_name" class="form-control" value="<?= htmlspecialchars($_POST['first_name'] ?? '') ?>">
                </div>

                <div class="col-md-6 mb-3">
                  <label class="form-label">Last Name</label>
                  <input type="text" name="last_name" class="form-control" value="<?= htmlspecialchars($_POST['last_name'] ?? '') ?>">
                </div>
              </div>

              <div class="mb-3">
                <label class="form-label">Username <span class="text-danger">*</span></label>
                <input type="text" name="username" class="form-control" required value="<?= htmlspecialchars($_POST['username'] ?? '') ?>">
              </div>

              <div class="mb-3">
                <label class="form-label">Email <span class="text-danger">*</span></label>
                <input type="email" name="email" class="form-control" required value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
              </div>

              <div class="row">
                <div class="col-md-6 mb-3">
                  <label class="form-label">Gender</label>
                  <select name="gender" class="form-select">
                    <option value="">Select gender</option>
                    <option value="Male" <?= (($_POST['gender'] ?? '') === 'Male') ? 'selected' : '' ?>>Male</option>
                    <option value="Female" <?= (($_POST['gender'] ?? '') === 'Female') ? 'selected' : '' ?>>Female</option>
                    <option value="Other" <?= (($_POST['gender'] ?? '') === 'Other') ? 'selected' : '' ?>>Other</option>
                  </select>
                </div>

                <div class="col-md-6 mb-3">
                  <label class="form-label">Date of Birth</label>
                  <input type="date" name="dob" class="form-control" value="<?= htmlspecialchars($_POST['dob'] ?? '') ?>">
                </div>
              </div>

              <div class="row">
                <div class="col-md-6 mb-3">
                  <label class="form-label">Password <span class="text-danger">*</span></label>
                  <input type="password" name="password" class="form-control" required>
                  <div class="form-text">Use at least 6 characters.</div>
                </div>

                <div class="col-md-6 mb-3">
                  <label class="form-label">Confirm Password <span class="text-danger">*</span></label>
                  <input type="password" name="confirm_password" class="form-control" required>
                </div>
              </div>

              <button class="btn btn-gradient w-100 py-2" type="submit">
                <i class="bi bi-person-check me-2"></i>Create Account
              </button>
            </form>

            <p class="text-center mt-3 mb-0">
              Already have an account?
              <a href="login.php" class="purple-link">Login here</a>.
            </p>
          </div>
        </div>
      </div>
    </div>
  </div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>