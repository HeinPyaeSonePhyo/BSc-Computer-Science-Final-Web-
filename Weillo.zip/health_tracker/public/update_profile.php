<?php
session_start();
require_once __DIR__ . '/../config/Database.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'error' => 'Unauthorized'
    ]);
    exit;
}

$db = (new Database())->getConnection();
$userId = (int)$_SESSION['user_id'];

// Sanitize input
$first = trim($_POST['first_name'] ?? '');
$last = trim($_POST['last_name'] ?? '');
$gender = trim($_POST['gender'] ?? '');
$dob = trim($_POST['dob'] ?? '');
$currentPassword = $_POST['current_password'] ?? '';

// Validate required password
if ($currentPassword === '') {
    echo json_encode([
        'success' => false,
        'error' => 'Current password is required.'
    ]);
    exit;
}

// Validate gender
if ($gender !== '' && !in_array($gender, ['Male', 'Female', 'Other'], true)) {
    echo json_encode([
        'success' => false,
        'error' => 'Invalid gender selected.'
    ]);
    exit;
}

try {
    // Fetch current user password hash
    $stmt = $db->prepare("SELECT password_hash FROM users WHERE id = :id LIMIT 1");
    $stmt->execute([':id' => $userId]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        echo json_encode([
            'success' => false,
            'error' => 'User not found.'
        ]);
        exit;
    }

    // Verify password
    if (!password_verify($currentPassword, $user['password_hash'])) {
        echo json_encode([
            'success' => false,
            'error' => 'Incorrect password.'
        ]);
        exit;
    }

    // Normalize empty values to null
    $firstValue = ($first !== '') ? $first : null;
    $lastValue = ($last !== '') ? $last : null;
    $genderValue = ($gender !== '') ? $gender : null;
    $dobValue = ($dob !== '') ? $dob : null;

    $update = $db->prepare("
        UPDATE users
        SET first_name = :f,
            last_name = :l,
            gender = :g,
            dob = :d,
            updated_at = NOW()
        WHERE id = :id
    ");

    $update->execute([
        ':f' => $firstValue,
        ':l' => $lastValue,
        ':g' => $genderValue,
        ':d' => $dobValue,
        ':id' => $userId
    ]);

    echo json_encode([
        'success' => true
    ]);
} catch (Throwable $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Failed to update profile.'
    ]);
}