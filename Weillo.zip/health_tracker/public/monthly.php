<?php
session_start();
require_once __DIR__ . '/../config/Database.php';
require_once __DIR__ . '/../controllers/EntryController.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

date_default_timezone_set('Europe/London');

$db = (new Database())->getConnection();
$entryController = new EntryController($db);
$userId = (int)$_SESSION['user_id'];

$selectedMonth = isset($_GET['month']) && $_GET['month'] !== ''
    ? $_GET['month']
    : date('Y-m');

$entries = $entryController->getMonthlyEntries($userId, $selectedMonth);

function calculateHealthScore(array $entry, ?float $goalWeightKg = null): array
{
    $weight = isset($entry['weight']) && $entry['weight'] !== '' ? (float)$entry['weight'] : null;
    $sys    = isset($entry['blood_pressure_sys']) && $entry['blood_pressure_sys'] !== '' ? (int)$entry['blood_pressure_sys'] : null;
    $dia    = isset($entry['blood_pressure_dia']) && $entry['blood_pressure_dia'] !== '' ? (int)$entry['blood_pressure_dia'] : null;
    $sleep  = isset($entry['sleep_hours']) && $entry['sleep_hours'] !== '' ? (float)$entry['sleep_hours'] : null;

    $sleepScore = null;
    if ($sleep !== null) {
        if ($sleep >= 7 && $sleep <= 9) {
            $sleepScore = 100;
        } else {
            $diff = abs($sleep - 8.0);
            $sleepScore = max(0, 100 - $diff * 20);
        }
    }

    $bpScore = null;
    if ($sys !== null && $dia !== null) {
        $targetSys = 115;
        $targetDia = 75;

        $sysError = abs($sys - $targetSys);
        $diaError = abs($dia - $targetDia);

        $bpScore = 100 - ($sysError * 1.5 + $diaError * 2.0);
        if ($bpScore < 0) $bpScore = 0;
    }

    $weightScore = null;
    if ($weight !== null && $goalWeightKg !== null && $goalWeightKg > 0) {
        $delta = abs($weight - $goalWeightKg);
        $weightScore = max(0, 100 - $delta * 5);
    }

    $sleepWeight  = ($sleepScore !== null)  ? 0.4 : 0.0;
    $bpWeight     = ($bpScore !== null)     ? 0.4 : 0.0;
    $weightWeight = ($weightScore !== null) ? 0.2 : 0.0;

    $weightSum = $sleepWeight + $bpWeight + $weightWeight;
    if ($weightSum <= 0) {
        return ['score' => null, 'label' => 'No data'];
    }

    $rawScore = 0;
    if ($sleepScore !== null)  $rawScore += $sleepScore * $sleepWeight;
    if ($bpScore !== null)     $rawScore += $bpScore * $bpWeight;
    if ($weightScore !== null) $rawScore += $weightScore * $weightWeight;

    $rawScore = $rawScore / $weightSum;
    $score = (int) round($rawScore);

    if ($score >= 80) {
        $label = 'Great';
    } elseif ($score >= 60) {
        $label = 'Okay';
    } else {
        $label = 'Needs attention';
    }

    return ['score' => $score, 'label' => $label];
}

$goalWeightKg = 70.0;

$labels        = [];
$weights       = [];
$bpSys         = [];
$bpDia         = [];
$sleepHours    = [];
$healthScores  = [];

foreach ($entries as $row) {
    $labels[]     = $row['entry_date'];
    $weights[]    = (float)$row['weight'];
    $bpSys[]      = (int)$row['blood_pressure_sys'];
    $bpDia[]      = (int)$row['blood_pressure_dia'];
    $sleepHours[] = (float)$row['sleep_hours'];

    $hs = calculateHealthScore($row, $goalWeightKg);
    $healthScores[] = $hs['score'];
}

$self = basename(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Monthly Health Graph</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
  <link rel="stylesheet" href="style.css?v=design-refresh-1">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>

<body>
<div class="app-shell d-flex">
  <?php include __DIR__ . '/sidebar.php'; ?>

  <div class="flex-grow-1">
    <div class="topbar container py-3 d-flex align-items-center justify-content-between">
      <button class="btn btn-outline-secondary d-inline-flex align-items-center gap-2 d-md-none" id="sidebarToggle">
        <i class="bi bi-list"></i> Menu
      </button>
      <div class="ms-auto">
        <p class="fw-semibold text-purple fs-5 mb-0">
          <i class="bi bi-graph-up-arrow me-2"></i>
          Monthly Health Graph (<?= htmlspecialchars($selectedMonth) ?>)
        </p>
      </div>
    </div>

    <main id="content">
      <div class="container pb-5">
        <div class="card mb-4 p-4 shadow-sm border-0">
          <form class="row g-3 align-items-end" method="get">
            <div class="col-sm-4">
              <label for="month" class="form-label mb-1">Select Month</label>
              <input
                type="month"
                id="month"
                name="month"
                class="form-control"
                value="<?= htmlspecialchars($selectedMonth) ?>"
                onchange="this.form.submit()"
              >
            </div>
          </form>
        </div>

        <div class="card p-4 shadow-sm border-0 mb-4">
          <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
            <h4 class="fw-bold mb-0 text-purple">Trends This Month</h4>
            <span class="badge badge-soft rounded-pill px-3 py-2"><?= htmlspecialchars($selectedMonth) ?></span>
          </div>

          <?php if (empty($entries)): ?>
            <p class="text-muted mb-0 text-center">No entries found for this month yet.</p>
          <?php else: ?>
            <div class="row g-4">
              <div class="col-12">
                <h6 class="text-center mb-2">Weight (kg)</h6>
                <div style="height: 300px;">
                  <canvas id="weightChart"></canvas>
                </div>
              </div>
              <div class="col-12">
                <h6 class="text-center mb-2">Blood Pressure (Sys / Dia)</h6>
                <div style="height: 300px;">
                  <canvas id="bpChart"></canvas>
                </div>
              </div>
              <div class="col-12">
                <h6 class="text-center mb-2">Sleep (hrs)</h6>
                <div style="height: 300px;">
                  <canvas id="sleepChart"></canvas>
                </div>
              </div>
              <div class="col-12">
                <h6 class="text-center mb-2">Health Score (0–100)</h6>
                <div style="height: 300px;">
                  <canvas id="healthChart"></canvas>
                </div>
              </div>
            </div>
          <?php endif; ?>
        </div>
      </div>
    </main>
  </div>
</div>

<script>
document.getElementById('sidebarToggle')?.addEventListener('click', () => {
  document.getElementById('sidebar').classList.toggle('open');
});

const labels = <?= json_encode($labels) ?>;
const weights = <?= json_encode($weights) ?>;
const bpSys = <?= json_encode($bpSys) ?>;
const bpDia = <?= json_encode($bpDia) ?>;
const sleepHours = <?= json_encode($sleepHours) ?>;
const healthScores = <?= json_encode($healthScores) ?>;

function buildChart(id, datasets) {
  const el = document.getElementById(id);
  if (!el) return;

  new Chart(el, {
    type: 'line',
    data: {
      labels,
      datasets
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      tension: 0.35,
      plugins: {
        legend: { display: true }
      },
      scales: {
        y: {
          beginAtZero: false
        }
      }
    }
  });
}

if (labels.length) {
  buildChart('weightChart', [{
    label: 'Weight',
    data: weights,
    borderWidth: 2
  }]);

  buildChart('bpChart', [
    { label: 'Systolic', data: bpSys, borderWidth: 2 },
    { label: 'Diastolic', data: bpDia, borderWidth: 2 }
  ]);

  buildChart('sleepChart', [{
    label: 'Sleep Hours',
    data: sleepHours,
    borderWidth: 2
  }]);

  buildChart('healthChart', [{
    label: 'Health Score',
    data: healthScores,
    borderWidth: 2
  }]);
}
</script>
</body>
</html>