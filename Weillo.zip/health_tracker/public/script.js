document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("apptForm");
  const providerSelect = document.getElementById("providerSelect");
  const providerName = document.getElementById("providerName");
  const providerType = document.getElementById("providerType");
  const providerTypeHidden = document.getElementById("providerTypeHidden");
  const apptMsg = document.getElementById("apptMsg");
  const apptDate = document.getElementById("apptDate");
  const apptTime = document.getElementById("apptTime");

  if (providerSelect) {
    providerSelect.addEventListener("change", function () {
      const selected = this.options[this.selectedIndex];
      const selectedValue = selected.value;
      const selectedType = selected.dataset.type || "Clinic";

      if (selectedValue === "__custom__") {
        providerName.value = "";
        providerName.readOnly = false;

        providerType.disabled = false;
        providerType.value = "Other";
        providerTypeHidden.value = "Other";

        providerName.focus();
      } else {
        providerName.value = selectedValue;
        providerName.readOnly = true;

        providerType.disabled = true;
        providerType.value = selectedType;
        providerTypeHidden.value = selectedType;
      }

      if (apptMsg) {
        apptMsg.textContent = "";
        apptMsg.classList.remove("text-danger");
      }
    });
  }

  if (providerType) {
    providerType.addEventListener("change", function () {
      providerTypeHidden.value = this.value;
    });
  }

  if (form) {
    form.addEventListener("submit", function (e) {
      providerTypeHidden.value = providerType.value;

      if (!providerName.value.trim()) {
        e.preventDefault();
        apptMsg.textContent = "Please select or enter a provider name.";
        apptMsg.classList.add("text-danger");
        return;
      }

      if (!apptDate.value.trim()) {
        e.preventDefault();
        apptMsg.textContent = "Please choose a date.";
        apptMsg.classList.add("text-danger");
        return;
      }

      if (!apptTime.value.trim()) {
        e.preventDefault();
        apptMsg.textContent = "Please choose a time.";
        apptMsg.classList.add("text-danger");
        return;
      }

      apptMsg.textContent = "Submitting...";
      apptMsg.classList.remove("text-danger");
    });
  }

  document.querySelectorAll(".cancel-btn").forEach((button) => {
    button.addEventListener("click", async function () {
      const appointmentId = this.dataset.id;

      if (!appointmentId) {
        alert("Invalid appointment ID.");
        return;
      }

      const confirmed = confirm("Are you sure you want to cancel this appointment?");
      if (!confirmed) return;

      try {
        const response = await fetch("cancel_appointment.php", {
          method: "POST",
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
          body: new URLSearchParams({
            appointment_id: appointmentId
          })
        });

        const result = await response.json();

        if (response.ok) {
          alert(result.message || "Appointment cancelled successfully.");
          window.location.reload();
        } else {
          alert(result.error || "Failed to cancel appointment.");
        }
      } catch (error) {
        alert("An error occurred while cancelling the appointment.");
        console.error(error);
      }
    });
  });
});