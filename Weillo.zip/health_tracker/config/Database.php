<?php

class Database
{
    private string $host;
    private string $dbName;
    private string $username;
    private string $password;
    private ?int $port;

    public function __construct()
    {
        $this->host = getenv('DB_HOST') ?: 'localhost';
        $this->dbName = getenv('DB_NAME') ?: 'health_tracker';
        $this->username = getenv('DB_USER') ?: 'root';
        $this->password = getenv('DB_PASSWORD') ?: '';
        $this->port = getenv('DB_PORT') ? (int) getenv('DB_PORT') : null;
    }

    public function getConnection(): \PDO
    {
        $dsn = sprintf(
            'mysql:host=%s;%sdbname=%s;charset=utf8mb4',
            $this->host,
            $this->port ? 'port=' . $this->port . ';' : '',
            $this->dbName
        );

        $options = [
            \PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION,
            \PDO::ATTR_DEFAULT_FETCH_MODE => \PDO::FETCH_ASSOC,
            \PDO::ATTR_EMULATE_PREPARES => false,
        ];

        return new \PDO($dsn, $this->username, $this->password, $options);
    }
}
