<?php
require_once __DIR__ . '/../config/Database.php';

class EntryController
{
    private \PDO $db;

    public function __construct(\PDO $db)
    {
        $this->db = $db;
    }

    /* --------- Queries used by index/save_record ---------- */

    public function getLatest(array $filters)
    {
        $sql = "SELECT * FROM entries
                WHERE user_id = :user_id
                ORDER BY entry_date DESC, id DESC
                LIMIT 1";

        $stmt = $this->db->prepare($sql);
        $stmt->execute([':user_id' => $filters['user_id']]);
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);

        return $row ?: null;
    }

    public function getByDate(int $userId, string $date)
    {
        $sql = "SELECT *
                FROM entries
                WHERE user_id = :user_id
                  AND entry_date = CAST(:d AS DATE)
                ORDER BY id DESC
                LIMIT 1";

        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            ':user_id' => $userId,
            ':d'       => $date
        ]);

        $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        return $row ?: null;
    }

    /**
     * Get all entries for a user for a given month (default: current month)
     * $month format: 'YYYY-MM' (e.g. '2025-11')
     */
    public function getMonthlyEntries(int $userId, ?string $month = null): array
    {
        if ($month === null) {
            $month = date('Y-m'); // current year-month
        }

        // first and last day of that month
        $start = $month . '-01';
        $end   = date('Y-m-t', strtotime($start)); // last day of month

        $sql = "SELECT 
                    entry_date,
                    weight,
                    blood_pressure_sys,
                    blood_pressure_dia,
                    sleep_hours,
                    notes
                FROM entries
                WHERE user_id = :user_id
                  AND entry_date BETWEEN :start AND :end
                ORDER BY entry_date ASC, id ASC";

        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            ':user_id' => $userId,
            ':start'   => $start,
            ':end'     => $end,
        ]);

        return $stmt->fetchAll(\PDO::FETCH_ASSOC);
    }

    /* ----------------- CRUD ----------------- */

    // Create new health entry
    public function create(array $data): array
    {
        $userId    = isset($data['user_id']) ? (int)$data['user_id'] : 0;
        $entryDate = $data['entry_date'] ?? null;
        $weight    = $data['weight'] ?? null;
        $sys       = $data['blood_pressure_sys'] ?? null;
        $dia       = $data['blood_pressure_dia'] ?? null;
        $sleep     = $data['sleep_hours'] ?? null;
        $notes     = $data['notes'] ?? null;

        if ($userId <= 0 || !$entryDate) {
            return [
                'status' => 400,
                'body'   => ['error' => 'user_id and entry_date are required.']
            ];
        }

        $stmt = $this->db->prepare(
            'INSERT INTO entries 
                (user_id, entry_date, weight, blood_pressure_sys, blood_pressure_dia, sleep_hours, notes, created_at, updated_at)
             VALUES 
                (:user_id, :entry_date, :weight, :sys, :dia, :sleep, :notes, NOW(), NOW())'
        );

        $stmt->execute([
            ':user_id'    => $userId,
            ':entry_date' => $entryDate,
            ':weight'     => $weight,
            ':sys'        => $sys,
            ':dia'        => $dia,
            ':sleep'      => $sleep,
            ':notes'      => $notes,
        ]);

        return [
            'status' => 201,
            'body'   => [
                'message'  => 'Entry created successfully.',
                'entry_id' => (int)$this->db->lastInsertId(),
            ],
        ];
    }

    // List entries for a user
    public function list(array $query): array
    {
        $userId = isset($query['user_id']) ? (int)$query['user_id'] : null;

        $sql    = 'SELECT * FROM entries';
        $params = [];

        if ($userId) {
            $sql .= ' WHERE user_id = :user_id';
            $params[':user_id'] = $userId;
        }

        $sql .= ' ORDER BY entry_date DESC, id DESC';

        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        $entries = $stmt->fetchAll(\PDO::FETCH_ASSOC);

        return [
            'status' => 200,
            'body'   => $entries
        ];
    }

    // Update existing entry
    public function update(int $id, array $data): array
    {
        if ($id <= 0) {
            return [
                'status' => 400,
                'body'   => ['error' => 'Invalid entry ID.']
            ];
        }

        $sql = "UPDATE entries 
                SET weight = :weight,
                    blood_pressure_sys = :sys,
                    blood_pressure_dia = :dia,
                    sleep_hours = :sleep,
                    notes = :notes,
                    updated_at = NOW()
                WHERE id = :id";

        $stmt = $this->db->prepare($sql);
        $ok   = $stmt->execute([
            ':weight' => $data['weight'] ?? null,
            ':sys'    => $data['blood_pressure_sys'] ?? null,
            ':dia'    => $data['blood_pressure_dia'] ?? null,
            ':sleep'  => $data['sleep_hours'] ?? null,
            ':notes'  => $data['notes'] ?? null,
            ':id'     => $id
        ]);

        if (!$ok || $stmt->rowCount() === 0) {
            // rowCount() can be 0 if values are identical; treat as success anyway
            return [
                'status' => 200,
                'body'   => ['message' => 'No changes or entry not found.']
            ];
        }

        return [
            'status' => 200,
            'body'   => ['message' => 'Entry updated successfully.']
        ];
    }

    public function delete(int $id): array
    {
        if ($id <= 0) {
            return [
                'status' => 400,
                'body'   => ['error' => 'Invalid entry ID.']
            ];
        }

        $stmt = $this->db->prepare('DELETE FROM entries WHERE id = :id');
        $stmt->execute([':id' => $id]);

        if ($stmt->rowCount() === 0) {
            return [
                'status' => 404,
                'body'   => ['error' => 'Entry not found.']
            ];
        }

        return [
            'status' => 200,
            'body'   => ['message' => 'Entry deleted successfully.']
        ];
    }
    /**
 * Calculate a simple health score (0–100) for one entry.
 *
 * Expected keys in $entry:
 *  - weight              (kg)
 *  - blood_pressure_sys  (int)
 *  - blood_pressure_dia  (int)
 *  - sleep_hours         (float)
 *
 * $goalWeightKg is optional. If null, weight has less impact.
 */
function calculateHealthScore(array $entry, ?float $goalWeightKg = null): array
{
    $weight = isset($entry['weight']) ? (float)$entry['weight'] : null;
    $sys    = isset($entry['blood_pressure_sys']) ? (int)$entry['blood_pressure_sys'] : null;
    $dia    = isset($entry['blood_pressure_dia']) ? (int)$entry['blood_pressure_dia'] : null;
    $sleep  = isset($entry['sleep_hours']) ? (float)$entry['sleep_hours'] : null;

    // ---- Sleep score (0–100) ----
    $sleepScore = 0;
    if ($sleep !== null) {
        if ($sleep >= 7 && $sleep <= 9) {
            $sleepScore = 100;
        } else {
            // penalise for being away from 8 hours
            $diff = abs($sleep - 8.0); // ideal in middle of 7–9
            // Every 1 hour away from 8 reduces 20 points.
            $sleepScore = max(0, 100 - $diff * 20);
        }
    }

    // ---- Blood pressure score (0–100) ----
    $bpScore = 0;
    if ($sys !== null && $dia !== null) {
        $targetSys = 115;
        $targetDia = 75;

        $sysError = abs($sys - $targetSys);
        $diaError = abs($dia - $targetDia);

        // Weight diastolic slightly more
        $bpScore = 100 - ($sysError * 1.5 + $diaError * 2.0);
        if ($bpScore < 0) {
            $bpScore = 0;
        }
    }

    // ---- Weight score (0–100) ----
    $weightScore = 0;
    if ($weight !== null && $goalWeightKg !== null && $goalWeightKg > 0) {
        $delta = abs($weight - $goalWeightKg);
        // Every 1kg from goal loses 5 points
        $weightScore = max(0, 100 - $delta * 5);
    } else {
       
        $weightScore = 100;
    }

    // ---- Combine into single score ----
    // If no BP or sleep available, avoid dividing by zero etc.
    $sleepWeight  = ($sleep !== null) ? 0.4 : 0.0;
    $bpWeight     = ($sys !== null && $dia !== null) ? 0.4 : 0.0;
    $weightWeight = 0.2;

    $weightSum = $sleepWeight + $bpWeight + $weightWeight;
    if ($weightSum <= 0) {
        // no data at all
        return [
            'score' => null,
            'label' => 'No data',
        ];
    }

    $rawScore = (
        $sleepScore  * $sleepWeight +
        $bpScore     * $bpWeight +
        $weightScore * $weightWeight
    ) / $weightSum;

    $score = (int) round($rawScore);

    // ---- Label ----
    if ($score >= 80) {
        $label = 'Great';
    } elseif ($score >= 60) {
        $label = 'Okay';
    } else {
        $label = 'Needs attention';
    }

    return [
        'score' => $score,
        'label' => $label,
    ];
}

}
