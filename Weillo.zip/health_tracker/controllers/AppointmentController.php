<?php
require_once __DIR__ . '/../config/Database.php';

class AppointmentController
{
    private \PDO $db;

    public function __construct(\PDO $db)
    {
        $this->db = $db;
    }

    public function create(array $data): array
    {
        $userId  = isset($data['user_id']) ? (int)$data['user_id'] : 0;
        $name    = trim((string)($data['provider_name'] ?? ''));
        $type    = trim((string)($data['provider_type'] ?? 'Clinic'));
        $date    = trim((string)($data['appointment_date'] ?? ''));
        $time    = trim((string)($data['appointment_time'] ?? ''));
        $reason  = trim((string)($data['reason'] ?? ''));
        $notes   = trim((string)($data['notes'] ?? ''));

        if ($userId <= 0 || $name === '' || $date === '' || $time === '') {
            return [
                'status' => 400,
                'body' => ['error' => 'provider_name, appointment_date, appointment_time are required.']
            ];
        }

        $d = \DateTime::createFromFormat('Y-m-d', $date);
        if (!$d || $d->format('Y-m-d') !== $date) {
            return [
                'status' => 400,
                'body' => ['error' => 'Invalid appointment_date (YYYY-MM-DD).']
            ];
        }

        if (!preg_match('/^\d{2}:\d{2}$/', $time)) {
            return [
                'status' => 400,
                'body' => ['error' => 'Invalid appointment_time (HH:MM).']
            ];
        }

        $tz = new \DateTimeZone('Europe/London');
        $now = new \DateTime('now', $tz);

        $appointmentDateTime = \DateTime::createFromFormat('Y-m-d H:i', $date . ' ' . $time, $tz);
        if (!$appointmentDateTime) {
            return [
                'status' => 400,
                'body' => ['error' => 'Invalid date/time combination.']
            ];
        }

        if ($appointmentDateTime < $now) {
            return [
                'status' => 400,
                'body' => ['error' => 'You cannot book an appointment in the past.']
            ];
        }

        $allowedTypes = ['Hospital', 'Clinic', 'GP', 'Pharmacy', 'Other'];
        if (!in_array($type, $allowedTypes, true)) {
            $type = 'Clinic';
        }

        $stmt = $this->db->prepare(
            "INSERT INTO appointments
             (user_id, provider_name, provider_type, appointment_date, appointment_time, reason, notes, status, created_at, updated_at)
             VALUES
             (:user_id, :provider_name, :provider_type, :appointment_date, :appointment_time, :reason, :notes, 'Booked', NOW(), NOW())"
        );

        $stmt->execute([
            ':user_id'          => $userId,
            ':provider_name'    => $name,
            ':provider_type'    => $type,
            ':appointment_date' => $date,
            ':appointment_time' => $time,
            ':reason'           => ($reason !== '' ? $reason : null),
            ':notes'            => ($notes !== '' ? $notes : null),
        ]);

        return [
            'status' => 201,
            'body' => [
                'message' => 'Appointment booked successfully.',
                'appointment_id' => (int)$this->db->lastInsertId(),
            ]
        ];
    }

    public function listAll(int $userId): array
    {
        $stmt = $this->db->prepare(
            "SELECT *
             FROM appointments
             WHERE user_id = :user_id
             ORDER BY appointment_date DESC, appointment_time DESC, id DESC"
        );
        $stmt->execute([':user_id' => $userId]);
        return $stmt->fetchAll(\PDO::FETCH_ASSOC);
    }

    public function cancel(int $userId, int $appointmentId): array
    {
        $stmt = $this->db->prepare(
            "UPDATE appointments
             SET status = 'Cancelled', updated_at = NOW()
             WHERE id = :id AND user_id = :user_id AND status = 'Booked'"
        );

        $stmt->execute([
            ':id' => $appointmentId,
            ':user_id' => $userId
        ]);

        if ($stmt->rowCount() === 0) {
            return [
                'status' => 404,
                'body' => ['error' => 'Appointment not found or already cancelled.']
            ];
        }

        return [
            'status' => 200,
            'body' => ['message' => 'Appointment cancelled successfully.']
        ];
    }
}