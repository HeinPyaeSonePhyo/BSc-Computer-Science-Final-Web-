<?php

require_once __DIR__ . '/../config/Database.php';

class AuthController
{
    private \PDO $db;

    public function __construct(\PDO $db)
    {
        $this->db = $db;
    }

  
    public function register(array $data): array
    {
        // ---- Gather & sanitize ----
        $email      = isset($data['email']) ? trim($data['email']) : '';
        $password   = $data['password'] ?? '';

        $username   = isset($data['username'])   ? trim($data['username'])   : '';
        $first_name = isset($data['first_name']) ? trim($data['first_name']) : '';
        $last_name  = isset($data['last_name'])  ? trim($data['last_name'])  : '';
        $gender     = isset($data['gender'])     ? trim($data['gender'])     : '';
        $dob        = isset($data['dob'])        ? trim($data['dob'])        : '';

        // ---- Required fields ----
        if ($email === '' || $password === '') {
            return ['status' => 400, 'body' => ['error' => 'Email and password are required.']];
        }

        // ---- Email validation ----
        if (!filter_var($email, FILTER_VALIDATE_EMAIL) || !preg_match('/\.[a-zA-Z]{2,}$/', $email)) {
            return ['status' => 400, 'body' => ['error' => 'Invalid email format.']];
        }

        // ---- Optional: username validation  ----
        if ($username !== '') {
            if (!preg_match('/^[A-Za-z0-9_\.]{3,32}$/', $username)) {
                return ['status' => 400, 'body' => ['error' => 'Username must be 3–32 chars (letters, numbers, underscore, dot).']];
            }
        }

        // ---- Optional: gender whitelist ----
        if ($gender !== '') {
            $allowed = ['Male','Female','Other'];
            if (!in_array($gender, $allowed, true)) {
                return ['status' => 400, 'body' => ['error' => 'Gender must be Male, Female or Other.']];
            }
        }

        // ---- Optional: DOB validation (YYYY-MM-DD) ----
        if ($dob !== '') {
            $d = \DateTime::createFromFormat('Y-m-d', $dob);
            $valid = $d && $d->format('Y-m-d') === $dob;
            if (!$valid) {
                return ['status' => 400, 'body' => ['error' => 'Date of birth must be in YYYY-MM-DD format.']];
            }
        }

        // ---- Uniqueness checks ----
        // email
        $checkEmail = $this->db->prepare('SELECT id FROM users WHERE email = :email LIMIT 1');
        $checkEmail->execute([':email' => $email]);
        if ($checkEmail->fetch()) {
            return ['status' => 409, 'body' => ['error' => 'Email is already registered.']];
        }

        // username (only if provided)
        if ($username !== '') {
            $checkUsername = $this->db->prepare('SELECT id FROM users WHERE username = :u LIMIT 1');
            $checkUsername->execute([':u' => $username]);
            if ($checkUsername->fetch()) {
                return ['status' => 409, 'body' => ['error' => 'Username is already taken.']];
            }
        }

        // ---- Hash password ----
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        // ---- Insert user ----
        $insert = $this->db->prepare(
            'INSERT INTO users
                (email, password_hash, username, first_name, last_name, gender, dob, created_at, updated_at)
             VALUES
                (:email, :password, :username, :first_name, :last_name, :gender, :dob, NOW(), NOW())'
        );

        $insert->execute([
            ':email'      => $email,
            ':password'   => $hashedPassword,
            ':username'   => ($username !== '' ? $username : null),
            ':first_name' => ($first_name !== '' ? $first_name : null),
            ':last_name'  => ($last_name !== '' ? $last_name : null),
            ':gender'     => ($gender !== '' ? $gender : null),
            ':dob'        => ($dob !== '' ? $dob : null),
        ]);

        return [
            'status' => 201,
            'body'   => [
                'message' => 'User registered successfully.',
                'user_id' => (int)$this->db->lastInsertId(),
            ],
        ];
    }

    /**
     * Login with email + password (unchanged)
     */
    public function login(array $data): array
    {
        $email    = isset($data['email']) ? trim($data['email']) : '';
        $password = $data['password'] ?? '';

        if ($email === '' || $password === '') {
            return ['status' => 400, 'body' => ['error' => 'Email and password are required.']];
        }

        $stmt = $this->db->prepare('SELECT id, password_hash FROM users WHERE email = :email LIMIT 1');
        $stmt->execute([':email' => $email]);
        $user = $stmt->fetch(\PDO::FETCH_ASSOC);

        if (!$user || !password_verify($password, $user['password_hash'])) {
            return ['status' => 401, 'body' => ['error' => 'Invalid credentials.']];
        }

        return [
            'status' => 200,
            'body'   => [
                'message' => 'Login successful.',
                'user_id' => (int)$user['id'],
            ],
        ];
    }
}
